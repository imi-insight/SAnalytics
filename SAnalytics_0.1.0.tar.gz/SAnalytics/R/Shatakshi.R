#Transformation steps: SQRT Function
transform<-function(x){
  y=sqrt(x)
  return(y)
}
transform(4)
#LOG Function
transform2<-function(i){
  z=log(i)
  return(z)
}
transform2(10)
